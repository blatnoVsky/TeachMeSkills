<?php

$data = array_map('str_getcsv', file('peoples.csv'));
$availableCountries = getAvailableCountries($data);
$country = $_POST['country'];
$name = $_POST['name'];
$isFull = $_POST['full'] == "on";
$searchPeoples = [];
if (!$country && !$name) {
    $searchPeoples = $data;
}

if ($country && $name) {
    foreach ($data as $people) {
        if (($country == $people[5]) && (($isFull && ($name == $people[1])) || (!$isFull && str_contains($people[1], $name)))) {
            $searchPeoples[] = $people;
        }
    }
} else if ($country && !$name) {
    foreach ($data as $people) {
        if ($country == $people[5]) {
            $searchPeoples[] = $people;
        }
    }
} else if (!$country && $name) {
    foreach ($data as $people) {
        if (($isFull && ($name == $people[1])) || (!$isFull && str_contains($people[1], $name))) {
            $searchPeoples[] = $people;
        }
    }
}

function getAvailableCountries(array $data): array
{
    $availableCountry = [];

    foreach ($data as $item) {
        $availableCountry[] = $item[5];
    }

    return array_unique($availableCountry);
}