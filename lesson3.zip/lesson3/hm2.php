<?php

print_r("Type a year: " . PHP_EOL);
$year = readline();

print_r(year($year));

function year($year) {

    if ($year % 4 == 0 && $year % 100 != 0 || $year % 400 == 0) {
        print_r($year . " является високосным годом.");
    } else {
        print_r($year . " не является високосным годом.");
    }
}