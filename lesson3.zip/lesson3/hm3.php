<?php

$open_days = date("w");
$time = date("H:i:s");


if ($open_days > 0 || open_days < 6 || $time < 21 || $time > 9)  {
    print_r("Магазин открыт");
    print_r("\n До закрытия осталось: " . (date("s:i:H", date("H:i:s", strotetime("21:00:00")) - $time)));
} else {
    print_r("Магазин закрыт");
}
