<?php

print_r("Определение четного или не четного числа");
print_r("\nВведите число: ");
$number = readline();

if ($number % 2 == 0) {
    print_r("Число " . $number . " четное");
} else {
    print_r("Число " . $number . " не четное");
}
