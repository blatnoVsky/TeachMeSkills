<?php

$cities = [
    'minsk',
    'london',
    'paris',
    'berlin'
];

$lowerletters = strtoupper($cities);

print_r($lowerletters);