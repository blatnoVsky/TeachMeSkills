<?php

print_r("Проверка на защитность сайта" . PHP_EOL);
print_r("Paste a website link: " . PHP_EOL);

$link = readline();

if (security($link)) {
    print_r("The website securited");
} else {
    print_r("The website does not securited");
}

function security($link): bool {

    if (str_starts_with($link, "https")) {
        return true;
    } else {
        return false;
    }
}
