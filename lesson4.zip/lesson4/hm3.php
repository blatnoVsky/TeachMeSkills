<?php

print_r("Check for valid format or not" . PHP_EOL);
print_r("Type a whole name of the image. example: image.jpg" . PHP_EOL);
$file = readline();
$formats = [".jpg", ".jpeg", ".png", ".svg"];

if (checkFormat($file, $formats[1])) {
    print_r("Valid format");
} else {
    print_r("Format does not valid");
}

function checkFormat($file, $formats): bool {
    if (str_ends_with($file, $formats[1])) {
        return true;
    } else {
        return false;
    }
}
