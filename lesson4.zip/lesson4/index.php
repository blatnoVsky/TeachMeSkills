<?php

$date = readline();

if ($date == 1) {
    print_r("Понедельник");
} elseif ($date == 2) {
    print_r("Вторник");
} elseif ($date == 3) {
    print_r("Среда");
} elseif ($date == 4) {
    print_r("Четверг");
} elseif ($date == 5) {
    print_r("Пятница");
} elseif ($date == 6) {
    print_r("Суббота");
} elseif ($date == 7) {
    print_r("Воскресенье");
}


